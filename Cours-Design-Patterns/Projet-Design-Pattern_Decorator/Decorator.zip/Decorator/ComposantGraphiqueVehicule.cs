public interface ComposantGraphiqueVehicule
{
  void affiche();
}
